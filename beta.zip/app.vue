<script setup lang="ts">
import ColorModeButton from './components/ColorModeButton.vue';
</script>

<template>
  <UApp>
    <NuxtPage />
    <div class="text-center py-2 z-10">
      <ColorModeButton />
    </div>
  </UApp>
</template>
